/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package eventplanner;

import java.util.ArrayList;
import java.util.Date;
import java.sql.Time;

/**
 *
 * @author Abii
 */
public class Business {

    String nameEvent;
    Time date;
   // int date;
    String room;
    String namePresenter;
    private ArrayList<String> labels = new ArrayList<String>();
    
    public Business(){
        
        
    }
    public Business(String nameEvent){
        
        this.nameEvent = nameEvent;
    }
    public Business(String nameEvent, Time date, String room, String namePresenter) {

        this.nameEvent = nameEvent;
        this.date = date;
        this.room = room;
        this.namePresenter = namePresenter;

    }
public Business(String nameEvent,  String room, String namePresenter) {

        this.nameEvent = nameEvent;
   
        this.room = room;
        this.namePresenter = namePresenter;

    }
    public String getNameEvent() {
        return nameEvent;
    }

    public void setNameEvent(String nameEvent) {
        this.nameEvent = nameEvent;
    }

    public Time getDate() {
        return date;
    }

    public void setDate(Time date) {
        this.date = date;
    }

    public String getRoom() {
        return room;
    }

    public void setRoom(String room) {
        this.room = room;
    }

    public String getNamePresenter() {
        return namePresenter;
    }

    public void setNamePresenter(String namePresenter) {
        this.namePresenter = namePresenter;
    }

    public ArrayList<String> getLabels() {
        return labels;
    }

    public void setLabels(ArrayList<String> newLabels) {
        labels = newLabels;
    }

    public ArrayList<Business> select(EventDatabase db) {
        ArrayList<Business> business = new ArrayList<Business>();

        business = db.getDataWithColumns("SELECT event.event_name, time.time, room.room_name, presenter.presenter_firstname FROM (time INNER JOIN event ON time.time_id= event.time_id_start)"
                + "INNER JOIN room ON(time.time_id= room.room_id)INNER JOIN presenter ON (presenter.presenter_id = event.event_id ) ");
        for (int i = 0; i < business.size(); i++) {
            nameEvent = business.get(i).getNameEvent();
            date = business.get(i).getDate();
            room = business.get(i).getRoom();
            namePresenter = business.get(i).getNamePresenter();
        }
        return business;
    }
     public ArrayList<Business> orderByDate(EventDatabase db) {
        ArrayList<Business> business = new ArrayList<Business>();

        business = db.getDataWithColumns("SELECT event.event_name, time.time, room.room_name, presenter.presenter_firstname FROM (time INNER JOIN event ON time.time_id= event.time_id_start)"
                + "INNER JOIN room ON(time.time_id= room.room_id)INNER JOIN presenter ON (presenter.presenter_id = event.event_id ) ORDER BY time asc ");
        for (int i = 0; i < business.size(); i++) {
            nameEvent = business.get(i).getNameEvent();
            date = business.get(i).getDate();
            room = business.get(i).getRoom();
            namePresenter = business.get(i).getNamePresenter();
        }
        return business;
    }
     public ArrayList<Business> orderByRoom(EventDatabase db) {
        ArrayList<Business> business = new ArrayList<Business>();

        business = db.getDataWithColumns("SELECT event.event_name, time.time, room.room_name, presenter.presenter_firstname FROM (time INNER JOIN event ON time.time_id= event.time_id_start)"
                + "INNER JOIN room ON(time.time_id= room.room_id)INNER JOIN presenter ON (presenter.presenter_id = event.event_id ) ORDER BY room_name asc ");
        for (int i = 0; i < business.size(); i++) {
            nameEvent = business.get(i).getNameEvent();
            date = business.get(i).getDate();
            room = business.get(i).getRoom();
            namePresenter = business.get(i).getNamePresenter();
        }
        return business;
    }
      public ArrayList<Business> orderByPresenter(EventDatabase db) {
        ArrayList<Business> business = new ArrayList<Business>();

        business = db.getDataWithColumns("SELECT event.event_name, time.time, room.room_name, presenter.presenter_firstname FROM (time INNER JOIN event ON time.time_id= event.time_id_start)"
                + "INNER JOIN room ON(time.time_id= room.room_id)INNER JOIN presenter ON (presenter.presenter_id = event.event_id ) ORDER BY presenter_firstname asc ");
        for (int i = 0; i < business.size(); i++) {
            nameEvent = business.get(i).getNameEvent();
            date = business.get(i).getDate();
            room = business.get(i).getRoom();
            namePresenter = business.get(i).getNamePresenter();
        }
        return business;
    }
     
    public static String printEvents(ArrayList<Business> events)  {
        String result = "";
      //  if (events.size() != 0) {

            for (int i = 0; i < events.size(); i++) {
                result += events.get(i).getNameEvent();
                result += " " + events.get(i).getDate();
                result += " " + events.get(i).getRoom();
                result += " " + events.get(i).getNamePresenter();
                result += "\n";
     //     }
        }
        return result;

    }
}
